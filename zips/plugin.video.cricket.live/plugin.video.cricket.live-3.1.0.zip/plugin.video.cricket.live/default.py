import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import json
import os
import re

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CHANNELS_FILE = os.path.join(ADDON_PATH, 'resources', 'channels.json')

# DaddyLive working domains (tested March 2026)
DADDY_DOMAIN = 'daddylive.cv'
DADDY_FALLBACKS = ['daddylive.im', 'daddylive.top']

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# Cache for channel/player data (per session)
_channel_data_cache = {}
_player9_cache = {}


def get_url(**kwargs):
    return '{}?{}'.format(BASE_URL, urllib.parse.urlencode(kwargs))


def http_get(url, headers=None):
    """Simple HTTP GET with user-agent."""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        resp = urlopen(req, timeout=15)
        return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        xbmc.log('MyATV HTTP Error: {} - {}'.format(url, str(e)), xbmc.LOGERROR)
        return None


def load_channels():
    with open(CHANNELS_FILE, 'r') as f:
        return json.load(f)


def get_working_domain():
    """Find a working DaddyLive domain."""
    for domain in [DADDY_DOMAIN] + DADDY_FALLBACKS:
        try:
            req = Request('https://{}/'.format(domain), headers={'User-Agent': USER_AGENT})
            resp = urlopen(req, timeout=8)
            if resp.getcode() == 200:
                return domain
        except Exception:
            continue
    return DADDY_DOMAIN


def fetch_live_schedule():
    """Fetch live sports schedule from DaddyLive."""
    domain = get_working_domain()

    # tv.json has the full daily schedule
    url = 'https://{}/cache/tv/tv.json'.format(domain)
    data = http_get(url)
    if data:
        try:
            return json.loads(data), domain, 'tv'
        except (ValueError, json.JSONDecodeError):
            pass

    return None, domain, None


def fetch_live_popular():
    """Fetch popular/live events from tv2.json."""
    domain = get_working_domain()

    url = 'https://{}/cache/tv2/tv2.json'.format(domain)
    data = http_get(url)
    if data:
        try:
            return json.loads(data), domain
        except (ValueError, json.JSONDecodeError):
            pass

    return None, domain


def normalize_name(name):
    """Normalize channel name for matching."""
    name = name.lower().strip()
    # Remove quality tags like (1080p), (720p), (576p)
    name = re.sub(r'\s*\(\d+p\)\s*', ' ', name)
    # Remove geo tags like [Geo-blocked]
    name = re.sub(r'\s*\[.*?\]\s*', ' ', name)
    # Remove extra spaces
    name = re.sub(r'\s+', ' ', name).strip()
    return name


def fetch_channel_and_player_data(domain):
    """Fetch channelData and player9Data from the stream page."""
    global _channel_data_cache, _player9_cache

    if _channel_data_cache and _player9_cache:
        return _channel_data_cache, _player9_cache

    # Use any channel ID to load the stream page (it contains the full database)
    url = 'https://{}/live/stream=1'.format(domain)
    html = http_get(url)
    if not html:
        return {}, {}

    # Extract channelData: maps numeric IDs to channel titles
    ch_match = re.search(r'channelData\s*=\s*(\[.*?\]);', html, re.DOTALL)
    if ch_match:
        try:
            ch_list = json.loads(ch_match.group(1))
            for ch in ch_list:
                _channel_data_cache[str(ch.get('id', ''))] = ch.get('title', '')
        except (ValueError, json.JSONDecodeError):
            pass

    # Extract player9Data: maps channel names to direct m3u8 URLs (8900+ entries)
    p9_idx = html.find('player9Data')
    if p9_idx >= 0:
        bracket_start = html.find('[', p9_idx)
        if bracket_start >= 0 and bracket_start - p9_idx < 50:
            depth = 0
            for i in range(bracket_start, min(bracket_start + 2000000, len(html))):
                if html[i] == '[':
                    depth += 1
                elif html[i] == ']':
                    depth -= 1
                if depth == 0:
                    try:
                        p9_list = json.loads(html[bracket_start:i + 1])
                        for entry in p9_list:
                            name = normalize_name(entry.get('name', ''))
                            if name and entry.get('url'):
                                _player9_cache[name] = entry['url']
                    except (ValueError, json.JSONDecodeError):
                        pass
                    break

    xbmc.log('MyATV: Loaded {} channels, {} player9 streams'.format(
        len(_channel_data_cache), len(_player9_cache)), xbmc.LOGINFO)

    return _channel_data_cache, _player9_cache


def find_stream_url(channel_title, player_data):
    """Find best matching m3u8 URL for a channel title."""
    if not channel_title or not player_data:
        return None

    needle = normalize_name(channel_title)

    # Exact match
    if needle in player_data:
        return player_data[needle]

    # Partial match - channel title contains or is contained in player name
    best_match = None
    best_score = 0
    for pname, purl in player_data.items():
        if needle in pname or pname in needle:
            score = len(needle) if needle in pname else len(pname)
            if score > best_score:
                best_score = score
                best_match = purl

    return best_match


def list_categories():
    xbmcplugin.setPluginCategory(HANDLE, 'MyATV')
    xbmcplugin.setContent(HANDLE, 'videos')

    # Live Now (popular/trending)
    li = xbmcgui.ListItem(label='[COLOR red][B]LIVE Now[/B][/COLOR]  (Popular matches)')
    li.setArt({'icon': 'DefaultVideo.png'})
    url = get_url(action='live_popular')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # Live Cricket shortcut
    li = xbmcgui.ListItem(label='[COLOR lime][B]LIVE Cricket[/B][/COLOR]')
    li.setArt({'icon': 'DefaultVideo.png'})
    url = get_url(action='live_cricket')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # Full Live Sports schedule
    li = xbmcgui.ListItem(label='[COLOR yellow][B]LIVE Sports Schedule[/B][/COLOR]  (All sports)')
    li.setArt({'icon': 'DefaultVideo.png'})
    url = get_url(action='live_sports')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # Static channel categories
    data = load_channels()
    categories = {}
    for ch in data['channels']:
        cat = ch.get('category', 'Other')
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(ch)

    for cat_name in categories:
        li = xbmcgui.ListItem(label='[B]{}[/B]  ({} channels)'.format(
            cat_name, len(categories[cat_name])))
        li.setArt({'icon': 'DefaultFolder.png'})
        url = get_url(action='list', category=cat_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # All channels
    all_count = len(data['channels'])
    li = xbmcgui.ListItem(label='[COLOR lime]All Channels[/COLOR]  ({})'.format(all_count))
    li.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='list', category='__all__')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_live_popular(filter_sport=None):
    """List popular live events from tv2.json."""
    category_name = filter_sport if filter_sport else 'Live Now'
    xbmcplugin.setPluginCategory(HANDLE, category_name)
    xbmcplugin.setContent(HANDLE, 'videos')

    popular, domain = fetch_live_popular()
    if not popular:
        xbmcgui.Dialog().notification('MyATV', 'Could not load live events', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    found = False
    for section_name, section_data in popular.items():
        if not isinstance(section_data, dict):
            continue
        events = section_data.get('Live Events', [])
        if not isinstance(events, list):
            continue

        for event in events:
            if not isinstance(event, dict):
                continue
            event_name = event.get('event', '')
            channels = event.get('channels', [])
            time_str = event.get('time', 'Live')

            if not event_name or not channels:
                continue

            # Filter for cricket if requested
            if filter_sport and filter_sport.lower() not in event_name.lower():
                continue

            # List each stream link for this event
            for ch in channels:
                if not isinstance(ch, dict):
                    continue
                ch_name = ch.get('channel_name', 'Unknown')
                ch_id = ch.get('channel_id', '')

                if not ch_id:
                    continue

                label = '[COLOR red]{}[/COLOR] | {} | [COLOR gray]{}[/COLOR]'.format(
                    time_str, event_name, ch_name)

                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {
                    'title': event_name,
                    'plot': '{}\nChannel: {}'.format(event_name, ch_name)
                })
                li.setProperty('IsPlayable', 'true')

                stream_url = get_url(action='play_live', channel_id=ch_id,
                                     domain=domain, name=event_name, source='tv2')
                xbmcplugin.addDirectoryItem(HANDLE, stream_url, li, isFolder=False)
                found = True

    if not found:
        msg = 'No live cricket right now' if filter_sport else 'No live events right now'
        li = xbmcgui.ListItem(label='[COLOR gray]{}[/COLOR]'.format(msg))
        xbmcplugin.addDirectoryItem(HANDLE, '', li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def list_live_sports(filter_sport=None):
    """List live/upcoming sports events from tv.json full schedule."""
    category_name = filter_sport if filter_sport else 'Live Sports'
    xbmcplugin.setPluginCategory(HANDLE, category_name)
    xbmcplugin.setContent(HANDLE, 'videos')

    schedule, domain, source = fetch_live_schedule()
    if not schedule:
        xbmcgui.Dialog().notification('MyATV', 'Could not load schedule', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    found = False
    for day_name, day_data in schedule.items():
        if not isinstance(day_data, dict):
            continue
        for sport_name, events in day_data.items():
            if not isinstance(events, list):
                continue
            # Filter for cricket if requested
            if filter_sport and filter_sport.lower() not in sport_name.lower():
                continue

            for event in events:
                if not isinstance(event, dict):
                    continue
                time_str = event.get('time', '')
                event_name = event.get('event', '')
                channels = event.get('channels', [])

                if not event_name or not channels:
                    continue

                # List each channel for this event
                for ch in channels:
                    if not isinstance(ch, dict):
                        continue
                    ch_name = ch.get('channel_name', 'Unknown')
                    ch_id = ch.get('channel_id', '')

                    if not ch_id:
                        continue

                    label = '[COLOR yellow]{}[/COLOR] | [B]{}[/B] {} | [COLOR gray]{}[/COLOR]'.format(
                        time_str, sport_name, event_name, ch_name)

                    li = xbmcgui.ListItem(label=label)
                    li.setInfo('video', {
                        'title': event_name,
                        'plot': '{}\n{}\n{}\nChannel: {}'.format(day_name, sport_name, time_str, ch_name)
                    })
                    li.setProperty('IsPlayable', 'true')

                    stream_url = get_url(action='play_live', channel_id=ch_id,
                                         domain=domain, name=event_name,
                                         ch_name=ch_name, source='tv')
                    xbmcplugin.addDirectoryItem(HANDLE, stream_url, li, isFolder=False)
                    found = True

    if not found:
        li = xbmcgui.ListItem(label='[COLOR gray]No live events found right now[/COLOR]')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def resolve_live_stream(channel_id, domain, ch_name='', source='tv'):
    """Resolve a channel to a playable m3u8 stream URL."""
    xbmc.log('MyATV: Resolving channel_id={} ch_name={} source={}'.format(
        channel_id, ch_name, source), xbmc.LOGINFO)

    # For tv.json (numeric IDs) - look up channel name then find m3u8
    if source == 'tv' and channel_id.isdigit():
        channel_data, player_data = fetch_channel_and_player_data(domain)

        # Get channel title from ID
        title = channel_data.get(channel_id, ch_name)
        if title:
            stream_url = find_stream_url(title, player_data)
            if stream_url:
                xbmc.log('MyATV: Resolved {} -> {} -> {}'.format(
                    channel_id, title, stream_url[:80]), xbmc.LOGINFO)
                return stream_url

    # For tv2.json (path-based IDs like "echo/match-name/1")
    # These use embedsports.top or similar - try the stream page directly
    if source == 'tv2':
        # The stream page URL pattern for tv2
        encoded_id = urllib.parse.quote(channel_id, safe='')
        page_url = 'https://{}/live/stream={}&source=tv2'.format(domain, encoded_id)
        html = http_get(page_url, headers={'Referer': 'https://{}/'.format(domain)})
        if html:
            # Try to find player9Data and match, or find direct m3u8
            m3u8_match = re.search(r'data-list9-url="(https?://[^"]*\.m3u8[^"]*)"', html)
            if m3u8_match:
                return m3u8_match.group(1)

            # Look for any m3u8 in script content
            m3u8_urls = re.findall(r'(https?://[^\s"\'<>]*\.m3u8[^\s"\'<>]*)', html)
            # Filter out generic/database URLs - pick one that looks specific
            for url in m3u8_urls:
                if 'playlist.m3u8' in url or 'index.m3u8' in url or 'master.m3u8' in url:
                    return url

    # Fallback: try the embed page patterns
    for embed_domain in [domain] + DADDY_FALLBACKS:
        embed_url = 'https://{}/embed/stream.php?id={}&player=1&source={}'.format(
            embed_domain, channel_id, source)
        html = http_get(embed_url, headers={
            'Referer': 'https://{}/'.format(domain),
            'X-Requested-With': 'XMLHttpRequest'
        })
        if html and '.m3u8' in html:
            m3u8_urls = re.findall(r'(https?://[^\s"\'<>]*\.m3u8[^\s"\'<>]*)', html)
            if m3u8_urls:
                return m3u8_urls[0]

    return None


def list_channels(category):
    xbmcplugin.setPluginCategory(HANDLE, category if category != '__all__' else 'All Channels')
    xbmcplugin.setContent(HANDLE, 'videos')

    data = load_channels()
    for ch in data['channels']:
        if category != '__all__' and ch.get('category', 'Other') != category:
            continue

        label = ch['name']
        if ch.get('quality'):
            label += '  [COLOR gray]({})[/COLOR]'.format(ch['quality'])
        if ch.get('region'):
            label += '  [COLOR cyan][{}][/COLOR]'.format(ch['region'])

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': ch['name'], 'plot': ch.get('description', '')})
        li.setProperty('IsPlayable', 'true')

        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})

        url = get_url(action='play', url=ch['url'], name=ch['name'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play(url, name):
    xbmc.log('MyATV: Playing {} - {}'.format(name, url), xbmc.LOGINFO)
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(HANDLE, True, play_item)


def play_live(channel_id, domain, name, ch_name='', source='tv'):
    """Resolve and play a live stream."""
    xbmc.log('MyATV: Resolving live channel {} from {}'.format(channel_id, domain), xbmc.LOGINFO)

    dialog = xbmcgui.DialogProgress()
    dialog.create('MyATV', 'Finding live stream...')
    dialog.update(20)

    stream_url = resolve_live_stream(channel_id, domain, ch_name, source)

    dialog.update(80)

    if stream_url:
        dialog.close()
        xbmc.log('MyATV: Playing stream: {}'.format(stream_url[:100]), xbmc.LOGINFO)
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    else:
        dialog.close()
        xbmcgui.Dialog().notification('MyATV', 'Stream not found. Try another link.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if action is None:
        list_categories()
    elif action == 'list':
        list_channels(params['category'])
    elif action == 'live_popular':
        list_live_popular()
    elif action == 'live_sports':
        list_live_sports()
    elif action == 'live_cricket':
        list_live_popular(filter_sport='Cricket')
    elif action == 'play':
        play(params['url'], params.get('name', ''))
    elif action == 'play_live':
        play_live(params['channel_id'], params['domain'],
                  params.get('name', ''), params.get('ch_name', ''),
                  params.get('source', 'tv'))


if __name__ == '__main__':
    router()
