import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import json
import os

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CHANNELS_FILE = os.path.join(ADDON_PATH, 'resources', 'channels.json')


def get_url(**kwargs):
    return '{}?{}'.format(BASE_URL, urllib.parse.urlencode(kwargs))


def load_channels():
    with open(CHANNELS_FILE, 'r') as f:
        return json.load(f)


def list_categories():
    xbmcplugin.setPluginCategory(HANDLE, 'Cricket Live')
    xbmcplugin.setContent(HANDLE, 'videos')

    data = load_channels()
    categories = {}
    for ch in data['channels']:
        cat = ch.get('category', 'Other')
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(ch)

    for cat_name in categories:
        li = xbmcgui.ListItem(label='[B]{}[/B]  ({} channels)'.format(
            cat_name, len(categories[cat_name])))
        li.setArt({'icon': 'DefaultFolder.png'})
        url = get_url(action='list', category=cat_name)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    # Also add "All Channels" option
    all_count = len(data['channels'])
    li = xbmcgui.ListItem(label='[COLOR lime]All Channels[/COLOR]  ({})'.format(all_count))
    li.setArt({'icon': 'DefaultFolder.png'})
    url = get_url(action='list', category='__all__')
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(category):
    xbmcplugin.setPluginCategory(HANDLE, category if category != '__all__' else 'All Channels')
    xbmcplugin.setContent(HANDLE, 'videos')

    data = load_channels()
    for ch in data['channels']:
        if category != '__all__' and ch.get('category', 'Other') != category:
            continue

        label = ch['name']
        if ch.get('quality'):
            label += '  [COLOR gray]({})[/COLOR]'.format(ch['quality'])
        if ch.get('region'):
            label += '  [COLOR cyan][{}][/COLOR]'.format(ch['region'])

        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': ch['name'], 'plot': ch.get('description', '')})
        li.setProperty('IsPlayable', 'true')

        if ch.get('logo'):
            li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})

        url = get_url(action='play', url=ch['url'], name=ch['name'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play(url, name):
    xbmc.log('Cricket Live: Playing {} - {}'.format(name, url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=url)

    # Use inputstream.adaptive only if installed, otherwise let Kodi handle natively
    try:
        enabled = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        if enabled:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    except Exception:
        pass

    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if action is None:
        list_categories()
    elif action == 'list':
        list_channels(params['category'])
    elif action == 'play':
        play(params['url'], params.get('name', ''))


if __name__ == '__main__':
    router()
